// ==========================================================================

//Sky4CE SSAO


static const half2 poisson_disc12[6] = 
{
	half2(-0.326212f , -0.405810f),
//	half2(-0.840144f , -0.073580f),
	half2(-0.695914f ,  0.457137f),
//	half2(-0.203345f ,  0.620716f),
	half2( 0.962340f , -0.194983f),
//	half2( 0.473434f , -0.480026f),
	half2( 0.519456f ,  0.767022f),
//	half2( 0.185461f , -0.893124f),
	half2( 0.507431f ,  0.064425f),
//	half2( 0.896420f ,  0.412458f),
	half2(-0.321940f , -0.932615f),
//	half2(-0.791559f , -0.597710f)
};

half	calc_ssao( half3 P, half3 N, half2 tc)
{
	half2 	scale 	= half2	(.61f / 1024.h, .61f / 768.h)*150/max(P.z,1.3);
	half occ = 0;
	half num_dir = 0;
	float c = 1;
	if(P.z<FADE_DIST)
	{
		c = FADE_COEF + ((1-FADE_COEF)*P.z)/FADE_DIST;
	}

	for (int a=1; a<SSAO_QUALITY; ++a)
	{
		half2	scale_tmp = scale*a;
		for (int i=0; i<6; i++)
		{
			half3 dir = tex2D( s_position, tc + poisson_disc12[ i ] * scale_tmp ) - P.xyz;
			half  occ_factor = saturate( length( dir ) );
			half  infl = clamp(dot( normalize( dir ), N.xyz ), 0, c );
			half  infl2 = infl + 0.01;
			half  occf = occ_factor + 0.1;
			occ += infl2 * lerp( 1, occ_factor, infl ) / occf;
			num_dir += infl2 / occf;

		}
	}

	occ /= num_dir;

	return occ;
} 


// ===============================================================================
